#include <iostream>
#include <string>
using namespace std;
int main()
{
    string s = "abc";
    s.back() = 0;
    cout << s<< endl;
    return 0;
}

